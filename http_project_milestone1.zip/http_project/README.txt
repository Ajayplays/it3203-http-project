IT 3203 Project Milestone 1 Website Files

Files included:
- index.html
- history.html
- modern-http.html
- key-concepts.html
- references.html
- about.html
- style.css
- images/http-flow.svg

How to use:
1. Upload all files to a GitHub repository.
2. Enable GitHub Pages in the repository settings.
3. Submit the live site URL and this zip file to D2L.
